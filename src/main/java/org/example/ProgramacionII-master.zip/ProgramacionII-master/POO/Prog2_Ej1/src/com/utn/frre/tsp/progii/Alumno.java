package com.utn.frre.tsp.progii;

public class Alumno {

    private String nombre;
    private String apellido;
    private int legajo;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
