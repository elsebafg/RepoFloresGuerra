public class Compra {
    String fecha;
    Persona comprador;
}
