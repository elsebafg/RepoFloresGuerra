package bodega;

public class Corcho {
    private boolean enBotella;
    private String bodega;

    public Corcho(){
        enBotella = true;
        bodega = "";
    }

    public boolean getEnBotella() {
        return enBotella;
    }
    public void setEnBotella(boolean enBotella) {
        this.enBotella = enBotella;
    }

}
